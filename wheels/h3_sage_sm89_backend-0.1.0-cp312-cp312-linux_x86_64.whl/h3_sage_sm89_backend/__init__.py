"""Explicit MiniMax H3 SageAttention backend for NVIDIA SM89."""

from .backend import (
    WanAnimate2SharedKVAttention,
    attention,
    attention_fp8_output,
    attention_prequantized_q,
    attention_prequantized_qk,
)

__all__ = [
    "WanAnimate2SharedKVAttention",
    "attention",
    "attention_fp8_output",
    "attention_prequantized_q",
    "attention_prequantized_qk",
]
