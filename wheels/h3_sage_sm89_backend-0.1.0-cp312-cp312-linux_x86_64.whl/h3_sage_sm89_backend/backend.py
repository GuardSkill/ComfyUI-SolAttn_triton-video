"""H3-only frontend for the four-V-tile SM89 attention kernel.

The installed SageAttention package continues to own Q/K and V quantization.
Only the prequantized attention launch is supplied by this package, so loading
it cannot replace Sage's global extension or change unrelated models.
"""

from __future__ import annotations

import torch

from sageattention.quant import per_channel_fp8

from . import _qattn_sm89_h3
from .preprocess import (
    quant_key_per_thread_sub_mean,
    quant_key_per_thread_sub_mean_into,
    quant_query_per_thread,
    quant_v_per_channel_into,
    quant_v_from_epilogue_stats,
)


def attention(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    *,
    tensor_layout: str = "NHD",
    sm_scale: float | None = None,
) -> torch.Tensor:
    """Run the exact H3 SM89 specialization.

    This entry point deliberately accepts only the contract measured on H3:
    non-causal BF16/FP16 self-attention, per-thread QK quantization and D=128.
    Unsupported inputs fail closed instead of silently selecting the kernel.
    """
    if not (q.is_cuda and k.is_cuda and v.is_cuda):
        raise ValueError("H3 SM89 attention requires CUDA tensors")
    if torch.cuda.get_device_capability(q.device) != (8, 9):
        raise ValueError("H3 SM89 attention requires compute capability 8.9")
    if tensor_layout not in {"NHD", "HND"}:
        raise ValueError(f"unsupported tensor layout: {tensor_layout}")
    if q.shape[-1] != 128 or k.shape[-1] != 128 or v.shape[-1] != 128:
        raise ValueError("H3 SM89 attention is specialized for head_dim=128")
    if q.dtype not in {torch.float16, torch.bfloat16}:
        raise ValueError(f"unsupported H3 attention dtype: {q.dtype}")
    if q.dtype != k.dtype or q.dtype != v.dtype or q.device != k.device or q.device != v.device:
        raise ValueError("H3 attention Q/K/V must share dtype and device")
    if q.stride(-1) != 1 or k.stride(-1) != 1 or v.stride(-1) != 1:
        raise ValueError("H3 attention Q/K/V must be contiguous in head_dim")

    torch.cuda.set_device(v.device)
    layout = 0 if tensor_layout == "NHD" else 1
    scale = 128**-0.5 if sm_scale is None else float(sm_scale)

    # Match Sage's Q/K contract while avoiding its materialized ``k-key_mean``
    # tensor (about 1.19 GiB at SCAIL2's 116K-token 720p shape).
    q_int8, q_scale = quant_query_per_thread(q, tensor_layout=tensor_layout)
    k_int8, k_scale = quant_key_per_thread_sub_mean(k, tensor_layout=tensor_layout)
    # fp32+fp16 is Sage's selected Ada/SM89 path. scale_max=2.25 is part of
    # that numerical contract and was used for the bit-exact H3 validation.
    v_fp8, v_scale, _ = per_channel_fp8(
        v, tensor_layout=tensor_layout, scale_max=2.25, smooth_v=False,
    )
    output = torch.empty_like(q)
    _qattn_sm89_h3.qk_int8_sv_f8_accum_f16_fuse_v_scale_attn_inst_buf(
        q_int8, k_int8, v_fp8, output, q_scale, k_scale, v_scale,
        layout, 0, 3, scale, 0,
    )
    return output


def attention_fp8_output(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    *,
    sm_scale: float | None = None,
) -> torch.Tensor:
    """Emit NHD E4M3 activations for a directly chained FP8 projection.

    This experimental contract deliberately uses unit activation scale, which
    matches ComfyUI's legacy FP8 fast-linear path. The SM89 attention kernel
    converts its final half fragments before global storage, eliminating the
    full-size half output and the standalone activation-quantization launch.
    """
    if not (q.is_cuda and k.is_cuda and v.is_cuda):
        raise ValueError("SM89 FP8-output attention requires CUDA tensors")
    if torch.cuda.get_device_capability(q.device) != (8, 9):
        raise ValueError("SM89 FP8-output attention requires compute capability 8.9")
    if q.ndim != 4 or q.shape[-1] != 128 or k.shape[-1] != 128 or v.shape[-1] != 128:
        raise ValueError("expected NHD Q/K/V with head_dim=128")
    if q.dtype not in {torch.float16, torch.bfloat16} or q.dtype != k.dtype or q.dtype != v.dtype:
        raise ValueError("Q/K/V must share FP16 or BF16 dtype")
    if q.device != k.device or q.device != v.device:
        raise ValueError("Q/K/V must share a CUDA device")
    q_int8, q_scale = quant_query_per_thread(q, tensor_layout="NHD")
    k_int8, k_scale = quant_key_per_thread_sub_mean(k, tensor_layout="NHD")
    v_fp8, v_scale, _ = per_channel_fp8(
        v, tensor_layout="NHD", scale_max=2.25, smooth_v=False,
    )
    output = torch.empty(q.shape, device=q.device, dtype=torch.float8_e4m3fn)
    scale = 128**-0.5 if sm_scale is None else float(sm_scale)
    _qattn_sm89_h3.qk_int8_sv_f8_accum_f16_fuse_v_scale_attn_inst_buf(
        q_int8, k_int8, v_fp8, output, q_scale, k_scale, v_scale,
        0, 0, 3, scale, 0,
    )
    return output


def attention_prequantized_q(
    q_int8: torch.Tensor,
    q_scale: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    vmax: torch.Tensor | None = None,
    *,
    tensor_layout: str = "NHD",
    sm_scale: float | None = None,
) -> torch.Tensor:
    """Run H3 SM89 attention from the native W4A4 Sage-Q epilogue."""
    if tensor_layout not in {"NHD", "HND"}:
        raise ValueError(f"unsupported tensor layout: {tensor_layout}")
    if q_int8.dtype != torch.int8 or q_scale.dtype != torch.float32:
        raise ValueError("prequantized Sage Q requires INT8 values and FP32 scales")
    if k.dtype != v.dtype or k.shape != v.shape or k.shape != q_int8.shape:
        raise ValueError("prequantized Q and BF16 K/V shapes must match")
    if k.shape[-1] != 128:
        raise ValueError("H3 SM89 attention is specialized for head_dim=128")
    layout = 0 if tensor_layout == "NHD" else 1
    scale = 128**-0.5 if sm_scale is None else float(sm_scale)
    k_int8, k_scale = quant_key_per_thread_sub_mean(k, tensor_layout=tensor_layout)
    if vmax is None:
        v_fp8, v_scale, _ = per_channel_fp8(
            v, tensor_layout=tensor_layout, scale_max=2.25, smooth_v=False,
        )
    else:
        v_fp8, v_scale = quant_v_from_epilogue_stats(v, vmax, tensor_layout=tensor_layout)
    output = torch.empty_like(k)
    _qattn_sm89_h3.qk_int8_sv_f8_accum_f16_fuse_v_scale_attn_inst_buf(
        q_int8, k_int8, v_fp8, output, q_scale, k_scale, v_scale,
        layout, 0, 3, scale, 0,
    )
    return output


def attention_prequantized_qk(
    q_int8: torch.Tensor,
    q_scale: torch.Tensor,
    k_int8: torch.Tensor,
    k_scale: torch.Tensor,
    v: torch.Tensor,
    *,
    tensor_layout: str = "NHD",
    sm_scale: float | None = None,
) -> torch.Tensor:
    """Launch the SM89 kernel from a fused Norm/RoPE/INT8 QK frontend."""
    if tensor_layout != "NHD":
        raise ValueError("prequantized Wan QK currently requires NHD layout")
    if q_int8.dtype != torch.int8 or k_int8.dtype != torch.int8:
        raise ValueError("prequantized Q/K values must be INT8")
    if q_scale.dtype != torch.float32 or k_scale.dtype != torch.float32:
        raise ValueError("prequantized Q/K scales must be FP32")
    if q_int8.ndim != 4 or k_int8.ndim != 4 or v.ndim != 4:
        raise ValueError("expected Q/K/V rank-four NHD tensors")
    if q_int8.shape[-2:] != k_int8.shape[-2:] or k_int8.shape != v.shape:
        raise ValueError("incompatible prequantized Q/K/V shapes")
    if q_int8.shape[-1] != 128 or v.dtype not in {torch.float16, torch.bfloat16}:
        raise ValueError("SM89 prequantized QK requires D=128 and FP16/BF16 V")
    v_fp8, v_scale, _ = per_channel_fp8(
        v, tensor_layout="NHD", scale_max=2.25, smooth_v=False,
    )
    output = torch.empty(q_int8.shape, device=v.device, dtype=v.dtype)
    scale = 128**-0.5 if sm_scale is None else float(sm_scale)
    _qattn_sm89_h3.qk_int8_sv_f8_accum_f16_fuse_v_scale_attn_inst_buf(
        q_int8, k_int8, v_fp8, output,
        q_scale, k_scale, v_scale,
        0, 0, 3, scale, 0,
    )
    return output


class WanAnimate2SharedKVAttention:
    """Incremental Sage frontend for WanAnimate2's per-frame pose attention.

    One instance owns one reusable K/V workspace. WanAnimate2 itself also uses
    one staging K/V buffer for every block. The generation prefix contains
    ``f_gen`` frame tiles and the rectangular loop makes exactly ``f_gen-1``
    calls, so the cache counter resets at every block without relying on tensor
    version counters (which are unavailable under torch.inference_mode).

    K and V use the first pose frame's full-KV statistics for the whole frame
    group. Subtracting a common K vector is softmax invariant, while keeping
    the statistics fixed makes cached prefix bytes and scales valid. This
    changes only later-frame quantization rounding versus Sage's full per-frame
    preprocessing and is gated behind explicit video quality validation.
    """

    def __init__(self, refresh_interval: int = 0):
        if refresh_interval < 0:
            raise ValueError("refresh_interval must be non-negative")
        self.refresh_interval = int(refresh_interval)
        self.reset()

    def reset(self) -> None:
        self.signature = None
        self.calls_in_group = 0
        self.calls_per_group = None
        self.incremental_since_rebuild = 0
        self.k_mean = None
        self.v_scale = None
        self.k_int8 = None
        self.k_scale = None
        self.v_fp8 = None
        self.full_rebuilds = 0
        self.tail_updates = 0
        self.k_tokens_requantized = 0
        self.v_tokens_requantized = 0

    @staticmethod
    def _signature(q, k, v, prefix_tokens):
        return (
            k.untyped_storage().data_ptr(), v.untyped_storage().data_ptr(),
            tuple(q.shape), tuple(k.shape), q.dtype, q.device, prefix_tokens,
        )

    def stats(self) -> dict[str, int]:
        return {
            "full_rebuilds": self.full_rebuilds,
            "tail_updates": self.tail_updates,
            "k_tokens_requantized": self.k_tokens_requantized,
            "v_tokens_requantized": self.v_tokens_requantized,
        }

    def __call__(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        *,
        tensor_layout: str = "NHD",
        sm_scale: float | None = None,
    ) -> torch.Tensor:
        if tensor_layout != "NHD":
            raise ValueError("WanAnimate2 shared-KV currently requires NHD layout")
        if not (q.is_cuda and k.is_cuda and v.is_cuda):
            raise ValueError("WanAnimate2 shared-KV requires CUDA tensors")
        if q.dtype not in {torch.float16, torch.bfloat16} or q.dtype != k.dtype or q.dtype != v.dtype:
            raise ValueError("Q/K/V must share BF16 or FP16 dtype")
        if q.ndim != 4 or k.ndim != 4 or v.shape != k.shape:
            raise ValueError("expected Q/K/V in [batch, tokens, heads, head_dim]")
        if q.shape[0] != k.shape[0] or q.shape[2:] != k.shape[2:] or q.shape[-1] != 128:
            raise ValueError("incompatible WanAnimate2 Q/K/V shapes")
        q_tokens, kv_tokens = q.shape[1], k.shape[1]
        prefix_tokens = kv_tokens - q_tokens
        if q_tokens <= 0 or prefix_tokens <= 0:
            raise ValueError("shared-KV requires a rectangular generation-prefix + pose-tail call")
        if prefix_tokens % q_tokens:
            raise ValueError("WanAnimate2 generation prefix must contain whole frame tiles")
        calls_per_group = prefix_tokens // q_tokens - 1
        if calls_per_group < 1:
            raise ValueError("WanAnimate2 shared-KV requires at least three generation frames")
        signature = self._signature(q, k, v, prefix_tokens)
        incremental = (
            signature == self.signature
            and calls_per_group == self.calls_per_group
            and 0 < self.calls_in_group < calls_per_group
            and (self.refresh_interval == 0
                 or self.incremental_since_rebuild < self.refresh_interval - 1)
        )

        b, _, heads, _ = k.shape
        if not incremental:
            # Match Sage exactly on the first pose frame, then keep those
            # statistics stable while subsequent frames replace only the
            # short tail. K mean subtraction is softmax invariant; holding V's
            # scale avoids touching the cached prefix layout.
            self.k_mean = k.mean(dim=1)
            self.k_int8 = torch.empty_like(k, dtype=torch.int8)
            self.k_scale = torch.empty(
                (b, heads, ((kv_tokens + 63) // 64) * 4),
                device=k.device, dtype=torch.float32,
            )
            # Use Sage's compiled frontend for the full build, preserving its
            # exact FP8 rounding. Incremental calls use the tile writer below.
            self.v_fp8, self.v_scale, _ = per_channel_fp8(
                v, tensor_layout="NHD", scale_max=2.25, smooth_v=False,
            )
            k_start, v_start = 0, kv_tokens
            self.full_rebuilds += 1
            self.incremental_since_rebuild = 0
        else:
            # Include the mixed prefix/tail tile. Completed prefix tiles stay cached.
            k_start = prefix_tokens // 64 * 64
            v_start = prefix_tokens // 16 * 16
            self.tail_updates += 1
            self.incremental_since_rebuild += 1

        quant_key_per_thread_sub_mean_into(
            k, self.k_mean, self.k_int8, self.k_scale,
            start_token=k_start, tensor_layout="NHD",
        )
        if v_start < kv_tokens:
            quant_v_per_channel_into(
                v, self.v_scale, self.v_fp8,
                start_token=v_start, tensor_layout="NHD",
            )
        self.k_tokens_requantized += kv_tokens - k_start
        self.v_tokens_requantized += kv_tokens - v_start

        q_int8, q_scale = quant_query_per_thread(q, tensor_layout="NHD")
        output = torch.empty_like(q)
        scale = 128**-0.5 if sm_scale is None else float(sm_scale)
        _qattn_sm89_h3.qk_int8_sv_f8_accum_f16_fuse_v_scale_attn_inst_buf(
            q_int8, self.k_int8, self.v_fp8, output,
            q_scale, self.k_scale, self.v_scale,
            0, 0, 3, scale, 0,
        )
        self.signature = signature
        self.calls_per_group = calls_per_group
        self.calls_in_group += 1
        if self.calls_in_group >= calls_per_group:
            self.calls_in_group = 0
        return output
