"""Exact Sage K-only preprocessing for the native H3 Q epilogue."""

from __future__ import annotations

import torch
import triton
import triton.language as tl


def quant_query_per_thread(q: torch.Tensor, *, tensor_layout: str):
    """Launch Sage's own Q quantizer without redundantly quantizing K."""
    from sageattention.triton.quant_per_thread import quant_query_per_thread_int8_kernel

    if tensor_layout == "NHD":
        b, length, heads, dim = q.shape
        stride_b, stride_h, stride_n = q.stride(0), q.stride(2), q.stride(1)
        output_head, output_seq = 2, 1
    elif tensor_layout == "HND":
        b, heads, length, dim = q.shape
        stride_b, stride_h, stride_n = q.stride(0), q.stride(1), q.stride(2)
        output_head, output_seq = 1, 2
    else:
        raise ValueError(f"unsupported tensor layout: {tensor_layout}")
    output = torch.empty_like(q, dtype=torch.int8)
    blocks = (length + 127) // 128
    scale = torch.empty((b, heads, blocks * 32), device=q.device, dtype=torch.float32)
    grid = (blocks * 32, heads, b)
    quant_query_per_thread_int8_kernel[grid](
        q, output, scale, length,
        stride_b, stride_h, stride_n,
        output.stride(0), output.stride(output_head), output.stride(output_seq),
        scale.stride(0), scale.stride(1), C=dim, BLK=32,
    )
    return output, scale


@triton.jit
def _finalize_q_scale_kernel(Scale, Count, BLOCK: tl.constexpr):
    offs = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    value = tl.load(Scale + offs, mask=offs < Count)
    tl.store(Scale + offs, value / 127.0 + 1.0e-7, mask=offs < Count)


def finalize_q_scale_(scale: torch.Tensor) -> torch.Tensor:
    count = scale.numel()
    # H3's scale tensor is small enough for a single launch but not a single
    # Triton program; use fixed 1024-element programs to keep register use low.
    block = 1024

    _finalize_q_scale_kernel[(triton.cdiv(count, block),)](scale, count, BLOCK=block)
    return scale


@triton.jit
def _quant_key_per_thread_sub_mean(
    Input, Mean, Output, Scale, L,
    stride_iz, stride_ih, stride_in,
    stride_mz, stride_mh,
    stride_oz, stride_oh, stride_on,
    stride_sz, stride_sh,
    START_BLOCK,
    C: tl.constexpr, BLK: tl.constexpr, IS_BF16: tl.constexpr,
):
    off_blk = START_BLOCK + tl.program_id(0) // 4
    off_tld = tl.program_id(0) % 4
    off_h = tl.program_id(1)
    off_b = tl.program_id(2)
    offs_n0 = off_blk * BLK + tl.arange(0, BLK // 8) * 8 + off_tld * 2
    offs_n1 = offs_n0 + 1
    offs_k = tl.arange(0, C)
    mean = tl.load(Mean + off_b * stride_mz + off_h * stride_mh + offs_k)
    ptr0 = Input + off_b * stride_iz + off_h * stride_ih + offs_n0[:, None] * stride_in + offs_k[None, :]
    ptr1 = Input + off_b * stride_iz + off_h * stride_ih + offs_n1[:, None] * stride_in + offs_k[None, :]
    mask0 = offs_n0[:, None] < L
    mask1 = offs_n1[:, None] < L
    x0 = tl.where(mask0, tl.load(ptr0, mask=mask0, other=0.0) - mean[None, :], 0.0)
    x1 = tl.where(mask1, tl.load(ptr1, mask=mask1, other=0.0) - mean[None, :], 0.0)
    # Match torch's materialized ``k - k.mean(...)`` before Sage quantization.
    if IS_BF16:
        x0 = x0.to(tl.bfloat16).to(tl.float32)
        x1 = x1.to(tl.bfloat16).to(tl.float32)
    else:
        x0 = x0.to(tl.float16).to(tl.float32)
        x1 = x1.to(tl.float16).to(tl.float32)
    scale = tl.maximum(tl.max(tl.abs(x0)), tl.max(tl.abs(x1))) / 127.0 + 1.0e-7
    q0 = x0 / scale
    q1 = x1 / scale
    q0 += 0.5 * tl.where(q0 >= 0, 1, -1)
    q1 += 0.5 * tl.where(q1 >= 0, 1, -1)
    out0 = Output + off_b * stride_oz + off_h * stride_oh + offs_n0[:, None] * stride_on + offs_k[None, :]
    out1 = Output + off_b * stride_oz + off_h * stride_oh + offs_n1[:, None] * stride_on + offs_k[None, :]
    tl.store(out0, q0.to(tl.int8), mask=offs_n0[:, None] < L)
    tl.store(out1, q1.to(tl.int8), mask=offs_n1[:, None] < L)
    tl.store(Scale + off_b * stride_sz + off_h * stride_sh + off_blk * 4 + off_tld, scale)


def quant_key_per_thread_sub_mean(k: torch.Tensor, *, tensor_layout: str):
    if tensor_layout == "NHD":
        b, length, heads, dim = k.shape
        seq_dim = 1
        stride_b, stride_h, stride_n = k.stride(0), k.stride(2), k.stride(1)
    elif tensor_layout == "HND":
        b, heads, length, dim = k.shape
        seq_dim = 2
        stride_b, stride_h, stride_n = k.stride(0), k.stride(1), k.stride(2)
    else:
        raise ValueError(f"unsupported tensor layout: {tensor_layout}")
    mean = k.mean(dim=seq_dim)
    output = torch.empty_like(k, dtype=torch.int8)
    scale = torch.empty((b, heads, ((length + 63) // 64) * 4), device=k.device, dtype=torch.float32)
    grid = (((length + 63) // 64) * 4, heads, b)
    _quant_key_per_thread_sub_mean[grid](
        k, mean, output, scale, length,
        stride_b, stride_h, stride_n,
        mean.stride(0), mean.stride(1),
        output.stride(0), output.stride(2 if tensor_layout == "NHD" else 1),
        output.stride(1 if tensor_layout == "NHD" else 2),
        scale.stride(0), scale.stride(1),
        0, C=dim, BLK=64, IS_BF16=k.dtype == torch.bfloat16,
    )
    return output, scale


def quant_key_per_thread_sub_mean_into(
    k: torch.Tensor,
    mean: torch.Tensor,
    output: torch.Tensor,
    scale: torch.Tensor,
    *,
    start_token: int,
    tensor_layout: str,
):
    """Rewrite K quantization from an aligned 64-token block onward.

    WanAnimate2 reuses a long generation prefix and overwrites only a short
    pose tail.  The first K block touched by that tail must be recomputed in
    full because Sage's four per-thread scales cover pairs within a 64-token
    block.  Completed prefix blocks remain byte-for-byte cached.
    """
    if start_token < 0 or start_token % 64:
        raise ValueError("start_token must be a non-negative multiple of 64")
    if tensor_layout == "NHD":
        b, length, heads, dim = k.shape
        stride_b, stride_h, stride_n = k.stride(0), k.stride(2), k.stride(1)
        out_h, out_n = output.stride(2), output.stride(1)
    elif tensor_layout == "HND":
        b, heads, length, dim = k.shape
        stride_b, stride_h, stride_n = k.stride(0), k.stride(1), k.stride(2)
        out_h, out_n = output.stride(1), output.stride(2)
    else:
        raise ValueError(f"unsupported tensor layout: {tensor_layout}")
    if output.shape != k.shape or output.dtype != torch.int8:
        raise ValueError("K output must be an INT8 tensor with K's shape")
    blocks = (length + 63) // 64
    if scale.shape != (b, heads, blocks * 4) or scale.dtype != torch.float32:
        raise ValueError("invalid K scale workspace")
    if mean.shape != (b, heads, dim):
        raise ValueError("K mean must have shape [batch, heads, head_dim]")
    start_block = start_token // 64
    remaining = blocks - start_block
    if remaining <= 0:
        return output, scale
    grid = (remaining * 4, heads, b)
    _quant_key_per_thread_sub_mean[grid](
        k, mean, output, scale, length,
        stride_b, stride_h, stride_n,
        mean.stride(0), mean.stride(1),
        output.stride(0), out_h, out_n,
        scale.stride(0), scale.stride(1),
        start_block, C=dim, BLK=64, IS_BF16=k.dtype == torch.bfloat16,
    )
    return output, scale


@triton.jit
def _reduce_vmax(VMax, VAmax, VScale, blocks: tl.constexpr, heads: tl.constexpr, dim: tl.constexpr,
                 BLOCKS: tl.constexpr):
    d = tl.program_id(0)
    h = tl.program_id(1)
    b = tl.program_id(2)
    offs = tl.arange(0, BLOCKS)
    values = tl.load(
        VMax + ((b * blocks + offs) * heads + h) * dim + d,
        mask=offs < blocks, other=0.0,
    )
    amax = tl.max(values)
    tl.store(VAmax + (b * heads + h) * dim + d, amax)
    tl.store(VScale + (b * heads + h) * dim + d, amax / 2.25)


@triton.jit
def _quant_v_transpose_permute(
    V, VScale, Output, length,
    stride_vb, stride_vn, stride_vh,
    stride_ob, stride_od, stride_oh,
    START_TILE,
    heads: tl.constexpr, dim: tl.constexpr,
):
    tile = START_TILE + tl.program_id(0)
    h = tl.program_id(1)
    b = tl.program_id(2)
    d = tl.arange(0, 128)[:, None]
    lane = tl.arange(0, 16)[None, :]
    token = tile * 16 + lane
    value = tl.load(
        V + b * stride_vb + token * stride_vn + h * stride_vh + d,
        mask=token < length, other=0.0,
    ).to(tl.float32)
    scale = tl.load(VScale + (b * heads + h) * dim + d)
    value = value / scale
    permuted_lane = (lane // 8) * 2 + ((lane // 2) % 4) * 4 + lane % 2
    output_token = tile * 16 + permuted_lane
    tl.store(Output + b * stride_ob + d * stride_od + h * stride_oh + output_token, value)


def quant_v_from_epilogue_stats(v: torch.Tensor, vmax: torch.Tensor, *, tensor_layout: str):
    if tensor_layout != "NHD":
        raise ValueError("native H3 V stats currently require NHD layout")
    b, length, heads, dim = v.shape
    if dim != 128 or vmax.shape != (b, (length + 63) // 64, heads, dim):
        raise ValueError("invalid native H3 V statistics shape")
    padded = (length + 63) // 64 * 64
    scale = torch.empty((b, heads, dim), device=v.device, dtype=torch.float32)
    amax = torch.empty_like(scale)
    blocks = vmax.shape[1]
    _reduce_vmax[(dim, heads, b)](
        vmax, amax, scale, blocks=blocks, heads=heads, dim=dim,
        BLOCKS=triton.next_power_of_2(blocks),
    )
    output = torch.zeros((b, dim, heads, padded), device=v.device, dtype=torch.float8_e4m3fn)
    from . import _qattn_sm89_h3
    _qattn_sm89_h3.quant_v_direct_nhd(v, amax, output)
    return output, scale


def quant_v_per_channel_into(
    v: torch.Tensor,
    scale: torch.Tensor,
    output: torch.Tensor,
    *,
    start_token: int,
    tensor_layout: str,
):
    """Rewrite Sage's transposed FP8 V layout from a 16-token tile boundary."""
    if tensor_layout != "NHD":
        raise ValueError("incremental V quantization currently requires NHD layout")
    if start_token < 0 or start_token % 16:
        raise ValueError("start_token must be a non-negative multiple of 16")
    b, length, heads, dim = v.shape
    padded = (length + 63) // 64 * 64
    if scale.shape != (b, heads, dim) or scale.dtype != torch.float32:
        raise ValueError("V scale must be FP32 [batch, heads, head_dim]")
    if output.shape != (b, dim, heads, padded) or output.dtype != torch.float8_e4m3fn:
        raise ValueError("invalid transposed FP8 V workspace")
    start_tile = start_token // 16
    tiles = (length + 15) // 16 - start_tile
    if tiles <= 0:
        return output
    _quant_v_transpose_permute[(tiles, heads, b)](
        v, scale, output, length,
        v.stride(0), v.stride(1), v.stride(2),
        output.stride(0), output.stride(1), output.stride(2),
        start_tile, heads=heads, dim=dim,
        num_warps=4,
    )
    return output
