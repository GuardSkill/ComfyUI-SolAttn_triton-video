"""Two-pass Wan Q/K RMSNorm -> 3D RoPE -> Sage INT8 frontend.

The first pass writes only two FP32 inverse-RMS scalars per token.  The second
pass rereads projection outputs and directly emits Sage's per-thread INT8
layout and scales, avoiding materialized normalized and RoPE Q/K tensors.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _rms_inv_kernel(X, Inv, rows, width, eps: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    d = tl.arange(0, BLOCK)
    x = tl.load(X + row * width + d, mask=d < width, other=0.0).to(tl.float32)
    inv = tl.rsqrt(tl.sum(x * x, axis=0) / width + eps)
    tl.store(Inv + row, inv)


@triton.jit
def _q_rope_quant_kernel(
    X, Inv, Weight, Freq, Out, Scale,
    length, width,
    sx_b, sx_n,
    sf_b, sf_n, sf_h, sf_p, sf_r, sf_c,
    so_b, so_n, so_h,
    ss_b, ss_h,
    HEADS: tl.constexpr, D: tl.constexpr,
    IS_BF16: tl.constexpr,
    PRENORMALIZED: tl.constexpr,
):
    group = tl.program_id(0)
    head = tl.program_id(1)
    batch = tl.program_id(2)
    block, lane = group // 8, group % 8
    token = block * 32 + tl.arange(0, 4) * 8 + lane
    d = tl.arange(0, D)
    pair, component = d // 2, d % 2
    valid = token < length
    base = batch * sx_b + token[:, None].to(tl.int64) * sx_n + head * D
    x0 = tl.load(X + base + pair[None, :] * 2, mask=valid[:, None], other=0.0).to(tl.float32)
    x1 = tl.load(X + base + pair[None, :] * 2 + 1, mask=valid[:, None], other=0.0).to(tl.float32)
    if not PRENORMALIZED:
        inv = tl.load(Inv + batch * length + token, mask=valid, other=0.0)
        w0 = tl.load(Weight + head * D + pair * 2).to(tl.float32)
        w1 = tl.load(Weight + head * D + pair * 2 + 1).to(tl.float32)
        x0 = x0 * inv[:, None] * w0[None, :]
        x1 = x1 * inv[:, None] * w1[None, :]
        if IS_BF16:
            x0, x1 = x0.to(tl.bfloat16).to(tl.float32), x1.to(tl.bfloat16).to(tl.float32)
        else:
            x0, x1 = x0.to(tl.float16).to(tl.float32), x1.to(tl.float16).to(tl.float32)
    fb = batch * sf_b
    fh = head * sf_h
    fbase = fb + token[:, None].to(tl.int64) * sf_n + fh + pair[None, :] * sf_p
    f0 = tl.load(Freq + fbase + component[None, :] * sf_r).to(tl.float32)
    f1 = tl.load(Freq + fbase + component[None, :] * sf_r + sf_c).to(tl.float32)
    y = f0 * x0 + f1 * x1
    if IS_BF16:
        y = y.to(tl.bfloat16).to(tl.float32)
    else:
        y = y.to(tl.float16).to(tl.float32)
    scale = tl.max(tl.where(valid[:, None], tl.abs(y), 0.0)) / 127.0 + 1.0e-7
    quant = y / scale
    quant += 0.5 * tl.where(quant >= 0, 1.0, -1.0)
    out_ptr = Out + batch * so_b + token[:, None].to(tl.int64) * so_n + head * so_h + d[None, :]
    tl.store(out_ptr, quant.to(tl.int8), mask=valid[:, None])
    tl.store(Scale + batch * ss_b + head * ss_h + group, scale)


@triton.jit
def _k_rope_sum_partial_kernel(
    X, Inv, Weight, Freq, Partial,
    length, width, chunks,
    sx_b, sx_n,
    sf_b, sf_n, sf_h, sf_p, sf_r, sf_c,
    HEADS: tl.constexpr, D: tl.constexpr, TOKENS: tl.constexpr,
    IS_BF16: tl.constexpr,
):
    chunk = tl.program_id(0)
    head = tl.program_id(1)
    batch = tl.program_id(2)
    token = chunk * TOKENS + tl.arange(0, TOKENS)
    d = tl.arange(0, D)
    pair, component = d // 2, d % 2
    valid = token < length
    base = batch * sx_b + token[:, None].to(tl.int64) * sx_n + head * D
    inv = tl.load(Inv + batch * length + token, mask=valid, other=0.0)
    w0 = tl.load(Weight + head * D + pair * 2).to(tl.float32)
    w1 = tl.load(Weight + head * D + pair * 2 + 1).to(tl.float32)
    x0 = tl.load(X + base + pair[None, :] * 2, mask=valid[:, None], other=0.0).to(tl.float32)
    x1 = tl.load(X + base + pair[None, :] * 2 + 1, mask=valid[:, None], other=0.0).to(tl.float32)
    x0 = x0 * inv[:, None] * w0[None, :]
    x1 = x1 * inv[:, None] * w1[None, :]
    if IS_BF16:
        x0, x1 = x0.to(tl.bfloat16).to(tl.float32), x1.to(tl.bfloat16).to(tl.float32)
    else:
        x0, x1 = x0.to(tl.float16).to(tl.float32), x1.to(tl.float16).to(tl.float32)
    fbase = (
        batch * sf_b + token[:, None].to(tl.int64) * sf_n + head * sf_h
        + pair[None, :] * sf_p
    )
    f0 = tl.load(Freq + fbase + component[None, :] * sf_r).to(tl.float32)
    f1 = tl.load(Freq + fbase + component[None, :] * sf_r + sf_c).to(tl.float32)
    y = f0 * x0 + f1 * x1
    if IS_BF16:
        y = y.to(tl.bfloat16).to(tl.float32)
    else:
        y = y.to(tl.float16).to(tl.float32)
    partial = tl.sum(tl.where(valid[:, None], y, 0.0), axis=0)
    tl.store(Partial + ((batch * chunks + chunk) * HEADS + head) * D + d, partial)


@triton.jit
def _reduce_k_mean_kernel(Partial, Mean, length, chunks, HEADS: tl.constexpr,
                          D: tl.constexpr, CHUNKS: tl.constexpr, IS_BF16: tl.constexpr):
    d = tl.program_id(0)
    head = tl.program_id(1)
    batch = tl.program_id(2)
    c = tl.arange(0, CHUNKS)
    values = tl.load(
        Partial + ((batch * chunks + c) * HEADS + head) * D + d,
        mask=c < chunks, other=0.0,
    )
    mean = tl.sum(values, axis=0) / length
    if IS_BF16:
        mean = mean.to(tl.bfloat16)
    else:
        mean = mean.to(tl.float16)
    tl.store(Mean + (batch * HEADS + head) * D + d, mean)


@triton.jit
def _k_rope_quant_kernel(
    X, Inv, Weight, Freq, Mean, Out, Scale,
    length, width,
    sx_b, sx_n,
    sf_b, sf_n, sf_h, sf_p, sf_r, sf_c,
    so_b, so_n, so_h,
    ss_b, ss_h,
    HEADS: tl.constexpr, D: tl.constexpr,
    IS_BF16: tl.constexpr,
):
    group = tl.program_id(0)
    head = tl.program_id(1)
    batch = tl.program_id(2)
    block, lane = group // 4, group % 4
    row = tl.arange(0, 16)
    token = block * 64 + (row % 8) * 8 + lane * 2 + row // 8
    d = tl.arange(0, D)
    pair, component = d // 2, d % 2
    valid = token < length
    base = batch * sx_b + token[:, None].to(tl.int64) * sx_n + head * D
    inv = tl.load(Inv + batch * length + token, mask=valid, other=0.0)
    w0 = tl.load(Weight + head * D + pair * 2).to(tl.float32)
    w1 = tl.load(Weight + head * D + pair * 2 + 1).to(tl.float32)
    x0 = tl.load(X + base + pair[None, :] * 2, mask=valid[:, None], other=0.0).to(tl.float32)
    x1 = tl.load(X + base + pair[None, :] * 2 + 1, mask=valid[:, None], other=0.0).to(tl.float32)
    x0 = x0 * inv[:, None] * w0[None, :]
    x1 = x1 * inv[:, None] * w1[None, :]
    if IS_BF16:
        x0, x1 = x0.to(tl.bfloat16).to(tl.float32), x1.to(tl.bfloat16).to(tl.float32)
    else:
        x0, x1 = x0.to(tl.float16).to(tl.float32), x1.to(tl.float16).to(tl.float32)
    fb = batch * sf_b
    fh = head * sf_h
    fbase = fb + token[:, None].to(tl.int64) * sf_n + fh + pair[None, :] * sf_p
    f0 = tl.load(Freq + fbase + component[None, :] * sf_r).to(tl.float32)
    f1 = tl.load(Freq + fbase + component[None, :] * sf_r + sf_c).to(tl.float32)
    y = f0 * x0 + f1 * x1
    if IS_BF16:
        y = y.to(tl.bfloat16).to(tl.float32)
    else:
        y = y.to(tl.float16).to(tl.float32)
    mean = tl.load(Mean + (batch * HEADS + head) * D + d).to(tl.float32)
    y = y - mean[None, :]
    # Match Sage's materialized BF16/FP16 ``k - k.mean(dim=1)``.
    if IS_BF16:
        y = y.to(tl.bfloat16).to(tl.float32)
    else:
        y = y.to(tl.float16).to(tl.float32)
    scale = tl.max(tl.where(valid[:, None], tl.abs(y), 0.0)) / 127.0 + 1.0e-7
    quant = y / scale
    quant += 0.5 * tl.where(quant >= 0, 1.0, -1.0)
    out_ptr = Out + batch * so_b + token[:, None].to(tl.int64) * so_n + head * so_h + d[None, :]
    tl.store(out_ptr, quant.to(tl.int8), mask=valid[:, None])
    tl.store(Scale + batch * ss_b + head * ss_h + group, scale)


def _freq_strides(freqs: torch.Tensor):
    if freqs.ndim != 6 or freqs.shape[-3:] != (64, 2, 2):
        raise ValueError(f"expected RoPE [B,T,H,64,2,2], got {tuple(freqs.shape)}")
    strides = list(freqs.stride())
    if freqs.shape[0] == 1:
        strides[0] = 0
    if freqs.shape[2] == 1:
        strides[2] = 0
    return tuple(strides)


def _rope_quant_with_inv(q_proj, k_proj, q_inv, k_inv, q_weight, k_weight, freqs, heads):
    b, length, width = q_proj.shape
    qi = torch.empty((b, length, heads, 128), device=q_proj.device, dtype=torch.int8)
    ki = torch.empty_like(qi)
    qs = torch.empty((b, heads, ((length + 127) // 128) * 32), device=q_proj.device, dtype=torch.float32)
    ks = torch.empty((b, heads, ((length + 63) // 64) * 4), device=q_proj.device, dtype=torch.float32)
    sf = _freq_strides(freqs)
    common = (
        length, width, q_proj.stride(0), q_proj.stride(1),
        sf[0], sf[1], sf[2], sf[3], sf[4], sf[5],
    )
    _q_rope_quant_kernel[(((length + 127) // 128) * 32, heads, b)](
        q_proj, q_inv, q_weight, freqs, qi, qs, *common,
        qi.stride(0), qi.stride(1), qi.stride(2), qs.stride(0), qs.stride(1),
        HEADS=heads, D=128, IS_BF16=q_proj.dtype == torch.bfloat16,
        PRENORMALIZED=False, num_warps=4,
    )
    common_k = (
        length, width, k_proj.stride(0), k_proj.stride(1),
        sf[0], sf[1], sf[2], sf[3], sf[4], sf[5],
    )
    sum_tokens = 32
    chunks = triton.cdiv(length, sum_tokens)
    partial = torch.empty((b, chunks, heads, 128), device=k_proj.device, dtype=torch.float32)
    k_mean = torch.empty((b, heads, 128), device=k_proj.device, dtype=k_proj.dtype)
    _k_rope_sum_partial_kernel[(chunks, heads, b)](
        k_proj, k_inv, k_weight, freqs, partial,
        length, width, chunks, k_proj.stride(0), k_proj.stride(1),
        sf[0], sf[1], sf[2], sf[3], sf[4], sf[5],
        HEADS=heads, D=128, TOKENS=sum_tokens,
        IS_BF16=k_proj.dtype == torch.bfloat16, num_warps=4,
    )
    _reduce_k_mean_kernel[(128, heads, b)](
        partial, k_mean, length, chunks,
        HEADS=heads, D=128, CHUNKS=triton.next_power_of_2(chunks),
        IS_BF16=k_proj.dtype == torch.bfloat16, num_warps=4,
    )
    _k_rope_quant_kernel[(((length + 63) // 64) * 4, heads, b)](
        k_proj, k_inv, k_weight, freqs, k_mean, ki, ks, *common_k,
        ki.stride(0), ki.stride(1), ki.stride(2), ks.stride(0), ks.stride(1),
        HEADS=heads, D=128, IS_BF16=k_proj.dtype == torch.bfloat16, num_warps=4,
    )
    return qi, qs, ki, ks


def fused_qk_norm_rope_quant(
    q_proj: torch.Tensor,
    k_proj: torch.Tensor,
    q_weight: torch.Tensor,
    k_weight: torch.Tensor,
    freqs: torch.Tensor,
    *,
    heads: int = 40,
    eps: float = 1.0e-6,
):
    """Return Sage INT8 Q/K and scales without BF16 normalized/RoPE tensors."""
    if q_proj.shape != k_proj.shape or q_proj.ndim != 3:
        raise ValueError("Q/K projections must share [batch, tokens, width]")
    b, length, width = q_proj.shape
    if width != heads * 128 or q_proj.stride(-1) != 1 or k_proj.stride(-1) != 1:
        raise ValueError("Wan fused frontend requires contiguous width=heads*128")
    if q_proj.dtype not in {torch.float16, torch.bfloat16} or k_proj.dtype != q_proj.dtype:
        raise ValueError("Q/K projections must share FP16 or BF16 dtype")
    q_inv = torch.empty((b, length), device=q_proj.device, dtype=torch.float32)
    k_inv = torch.empty_like(q_inv)
    grid_inv = (b * length,)
    _rms_inv_kernel[grid_inv](q_proj, q_inv, b * length, width, eps=eps, BLOCK=8192, num_warps=8)
    _rms_inv_kernel[grid_inv](k_proj, k_inv, b * length, width, eps=eps, BLOCK=8192, num_warps=8)
    return _rope_quant_with_inv(
        q_proj, k_proj, q_inv, k_inv, q_weight, k_weight, freqs, heads,
    )


def fused_rope_quant(q_norm, k_norm, freqs, *, heads: int = 40):
    """Quality-first hybrid: native RMSNorm followed by fused RoPE + Sage QK."""
    if q_norm.shape != k_norm.shape or q_norm.ndim != 3:
        raise ValueError("normalized Q/K must share [batch, tokens, width]")
    b, length, width = q_norm.shape
    if width != heads * 128 or q_norm.dtype != k_norm.dtype:
        raise ValueError("invalid normalized Wan Q/K tensors")
    inv = torch.ones((b, length), device=q_norm.device, dtype=torch.float32)
    weight = torch.ones((width,), device=q_norm.device, dtype=q_norm.dtype)
    return _rope_quant_with_inv(q_norm, k_norm, inv, inv, weight, weight, freqs, heads)


def fused_q_rope_quant(q_norm, freqs, *, heads: int = 40):
    """Bit-exact quality path: native Q RMSNorm, fused 3D RoPE + Sage Q."""
    if q_norm.ndim != 3:
        raise ValueError("normalized Q must be [batch, tokens, width]")
    b, length, width = q_norm.shape
    if width != heads * 128 or q_norm.dtype not in {torch.float16, torch.bfloat16}:
        raise ValueError("invalid normalized Wan Q tensor")
    qi = torch.empty((b, length, heads, 128), device=q_norm.device, dtype=torch.int8)
    qs = torch.empty((b, heads, ((length + 127) // 128) * 32), device=q_norm.device, dtype=torch.float32)
    sf = _freq_strides(freqs)
    _q_rope_quant_kernel[(((length + 127) // 128) * 32, heads, b)](
        q_norm, q_norm, q_norm, freqs, qi, qs,
        length, width, q_norm.stride(0), q_norm.stride(1),
        sf[0], sf[1], sf[2], sf[3], sf[4], sf[5],
        qi.stride(0), qi.stride(1), qi.stride(2), qs.stride(0), qs.stride(1),
        HEADS=heads, D=128, IS_BF16=q_norm.dtype == torch.bfloat16,
        PRENORMALIZED=True, num_warps=4,
    )
    return qi, qs


__all__ = ["fused_qk_norm_rope_quant", "fused_rope_quant", "fused_q_rope_quant"]
